var defaults = {
	Form : '',
	Error : 'This field is required',
	InvalidError : 'Enter Valid value',
	InvalidEmail : 'Enter valid email Id',
	InvalidPhone : 'Enter valid phone number',		
}
var FormV = {};
$.fn.vf = function(options){
	FormV.setting=$.extend({}, defaults, options);
}
$(document).ready(function(el){
	if(FormV.setting){
		$(FormV.setting.Form).submit(function(){
			ce='';
			v='';
			fe='';
			er=false;
			$(".vf-error").remove();
			$(FormV.setting.Form + " .vf-required").each(function(){
				v=$(this).val(); // getting input value				
				ce=$(this); // getting current selector
				var mn = ce.attr('vf-min');
				if (typeof mn !== typeof undefined && mn !== false) {
					mn=parseInt(mn);
				}else{
					mn=0;
				}
				var mx = ce.attr('vf-max');
				if (typeof mx !== typeof undefined && mx !== false) {
					mx=parseInt(mx);
				}else{
					mx=0;
				}
				if(!v){
					ce.after('<span class="vf-error">'+ FormV.setting.Error +'</span>');
					er=true;
					if(!fe){fe= $(this);} // setting element to focus
				}else if(($(this).hasClass("vf-phone")) && (!pv(v,$(this)))){
					ce.after('<span class="vf-error">'+ FormV.setting.InvalidPhone +'</span>');
					er=true;
					if(!fe){fe= $(this);} // setting element to focus
				}else if(($(this).hasClass("vf-email")) && (!ev(v))){
					ce.after('<span class="vf-error">'+ FormV.setting.InvalidEmail +'</span>');
					er=true;
					if(!fe){fe= $(this);} // setting element to focus
				}else if(mn && mx){
					if(v.length < mn ||  v.length > mx ){
						ce.after('<span class="vf-error">'+ FormV.setting.InvalidError + ' (' + mn + '-' + mx + ' charactors) </span>');
						if(!fe){fe= $(this);} // setting element to focus
					}
				}else if(mn){
					if(v.length < mn ){
						ce.after('<span class="vf-error">'+ FormV.setting.InvalidError + ' (' + mn + ' charactors) </span>');
						if(!fe){fe= $(this);} // setting element to focus
					}				
				}else if(mx){
					if(v.length > mx ){
						ce.after('<span class="vf-error">'+ FormV.setting.InvalidError + ' (0-' + mx + ' charactors) </span>');
						if(!fe){fe= $(this);} // setting element to focus
					}				
				}
				if(er){
					fe.focus();
				}	
			});
			if(er){
				return false;
			}else{
				return  true;
			}
		});
		$(FormV.setting.Form + ' .vf-required').keyup(function(){
			$(this).next('.vf-error').remove();
			v=$(this).val();// getting input value
			ce=$(this);// setting current selector
			er=false;// setting error satus as false
			fe='';// to get first element with error in value
			var mn = ce.attr('vf-min');
			if (typeof mn !== typeof undefined && mn !== false) {
				mn=parseInt(mn);
			}else{
				mn=0;
			}
			var mx = ce.attr('vf-max');
			if (typeof mx !== typeof undefined && mx !== false) {
				mx=parseInt(mx);
			}else{
				mx=0;
			}
			if(!v){
				ce.after('<span class="vf-error">'+ FormV.setting.Error +'</span>');
				er=true;
				if(!fe){fe= $(this);} // setting element to focus
			}else if(($(this).hasClass("vf-phone")) && (!pv(v,$(this)))){
				ce.after('<span class="vf-error">'+ FormV.setting.InvalidPhone +'</span>');
				er=true;
				if(!fe){fe= $(this);} // setting element to focus
			}else if(($(this).hasClass("vf-email")) && (!ev(v))){
				ce.after('<span class="vf-error">'+ FormV.setting.InvalidEmail +'</span>');
				er=true;
				if(!fe){fe= $(this);} // setting element to focus
			}else if(mn && mx){
				if(v.length < mn ||  v.length > mx ){
					ce.after('<span class="vf-error">'+ FormV.setting.InvalidError + ' (' + mn + '-' + mx + ' charactors) </span>');
					if(!fe){fe= $(this);} // setting element to focus
				}
			}else if(mn){
				if(v.length < mn ){
					ce.after('<span class="vf-error">'+ FormV.setting.InvalidError + ' (' + mn + ' charactors) </span>');
					if(!fe){fe= $(this);} // setting element to focus
				}				
			}else if(mx){
				if(v.length > mx ){
					ce.after('<span class="vf-error">'+ FormV.setting.InvalidError + ' (0-' + mx + ' charactors) </span>');
					if(!fe){fe= $(this);} // setting element to focus
				}				
			}
			if(er){
				fe.focus();
			}	
		});
	}
	/* EMAIL VALIDATOR START */
	function ev(em) {
		var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		return regex.test(em);
	}
	/* EMAIL VALIDATOR END */
	/* PHONE NUMBER VALIDATOR START */
	function pv(ph,obj){
		var pmn = obj.attr('vf-min');
		if (typeof pmn !== typeof undefined && pmn !== false) {
			pmn=parseInt(pmn);
		}else{
			pmn=0;
		}
		var pmx = obj.attr('vf-max');
		if (typeof pmx !== typeof undefined && pmx !== false) {
			pmx=parseInt(pmx);
		}else{
			pmx=99;
		}
		//alert(pmn + " " + pmx);
		if(($.isNumeric(ph)) && (ph.length >= pmn ) && (ph.length <= pmx) ) {return true;}
		else {return false;}
	}
	/* PHONE NUMBER VALIDATOR END */
});